"""
LGX : Discord — server status notifications via Discord Webhook
================================================================
• Server start  → posts an "ONLINE" announcement + @everyone (IP/Port)
• While online  → updates the online player count in that same message every N seconds
• Server stop/restart → edits that message to "Restarting..." (red)

No separate bot required — uses a Discord Webhook only.
Get a URL: Discord channel → Edit Channel → Integrations → Webhooks → New Webhook → Copy URL

Admin:
  /discord test              send a test ONLINE message now
  /discord now               re-post the online announcement (pings @everyone again)
  /discord restart           send the "restarting" message now
  /discord setwebhook <url>  set the webhook URL
  /discord status            show current settings
  /discord reload            reload config
"""

import datetime
import json
import os
import threading
import urllib.request
import urllib.error

from endstone.command import Command, CommandSender
from endstone.plugin import Plugin

PREFIX = "§l§9LGX-Discord§r §8» §r"
G = "§a"; R = "§c"; Y = "§e"; GR = "§7"; GO = "§6"; AQ = "§b"; W = "§f"; RS = "§r"; D = "§8"; B = "§9"

DEFAULT_CONFIG = {
    # ====== core ======
    "webhook_url": "",                      # <<< paste your webhook URL here, or use /discord setwebhook
    "server_name": "My Server",
    "server_ip": "play.example.net",
    "server_port": "19132",
    "max_players": 100,                     # shows X/Y (0 = hide the cap)

    # ====== mention ======
    "mention_everyone": True,               # server start = ping @everyone
    "mention_text": "@everyone",            # ping text (use <@&ROLEID> to ping a role instead)

    # ====== player count ======
    "show_player_count": True,
    "update_interval_sec": 60,              # how often to refresh the player count

    # ====== message look (editable) ======
    "online_title": "🎉 THE SERVER IS NOW ONLINE! 🎉",
    "online_desc": "🌍 **The server is open — come join!**\n\nHop in, explore, build, and play with everyone.\n\n🔥 Jump in and start your adventure now!",
    "online_color": 3066993,                # green 0x2ECC71
    "restart_title": "🔄 Server is restarting...",
    "restart_desc": "⚠️ The server is restarting and will be back shortly.\nHang tight and jump back in soon! 💚",
    "restart_color": 15158332,              # red 0xE74C3C
    "thumbnail_url": "",                    # optional server icon image URL (empty = none)
    "footer_text": "My Server",
}


class LGXDiscord(Plugin):
    api_version = "0.11"

    commands = {
        "discord": {
            "description": "Discord server-status notifications (admin)",
            "usages": ["/discord [action: message]"],
            "aliases": ["dc"],
            "permissions": ["lgxdiscord.admin"],
        },
    }
    permissions = {"lgxdiscord.admin": {"description": "Manage LGX Discord", "default": "op"}}

    # ================= lifecycle =================
    def on_enable(self) -> None:
        self._task = None
        self._load_config()
        self._load_state()
        # announce ONLINE on boot (in a thread so it never blocks startup)
        if self.cfg.get("webhook_url"):
            threading.Thread(target=self._send_online, daemon=True).start()
            self._start_updater()
        else:
            self.logger.warning(f"{Y}webhook_url not set — use /discord setwebhook <url> or edit config.json{RS}")
        self.logger.info(f"{G}LGX Discord ready!{RS}")

    def on_disable(self) -> None:
        # server is stopping/restarting — edit the message to "restarting" synchronously
        try:
            if self.cfg.get("webhook_url"):
                self._send_restart_blocking()
        except Exception as e:
            self.logger.warning(f"restart notify fail: {e}")

    # ================= config + state =================
    def _dir(self) -> str:
        folder = str(self.data_folder)
        os.makedirs(folder, exist_ok=True)
        return folder

    def _cfg_path(self) -> str:
        return os.path.join(self._dir(), "config.json")

    def _load_config(self) -> None:
        path = self._cfg_path()
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    self.cfg = {**DEFAULT_CONFIG, **json.load(f)}
            except Exception:
                self.cfg = json.loads(json.dumps(DEFAULT_CONFIG))
        else:
            self.cfg = json.loads(json.dumps(DEFAULT_CONFIG))
        self._save_config()

    def _save_config(self) -> None:
        try:
            with open(self._cfg_path(), "w", encoding="utf-8") as f:
                json.dump(self.cfg, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self.logger.warning(f"save config fail: {e}")

    def _state_path(self) -> str:
        return os.path.join(self._dir(), "state.json")

    def _load_state(self) -> None:
        try:
            with open(self._state_path(), "r", encoding="utf-8") as f:
                self._state = json.load(f)
        except Exception:
            self._state = {}

    def _save_state(self) -> None:
        try:
            with open(self._state_path(), "w", encoding="utf-8") as f:
                json.dump(self._state, f, ensure_ascii=False, indent=1)
        except Exception as e:
            self.logger.warning(f"save state fail: {e}")

    # ================= HTTP (Discord webhook) =================
    def _post_json(self, url: str, payload: dict, method: str = "POST", timeout: float = 8.0):
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, method=method,
                                     headers={"Content-Type": "application/json",
                                              "User-Agent": "LGX-Discord/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8", "replace")
            if body:
                try:
                    return json.loads(body)
                except Exception:
                    return None
        return None

    def _now_ts(self) -> str:
        try:
            return datetime.datetime.now(datetime.timezone.utc).isoformat()
        except Exception:
            return ""

    # ================= build embeds =================
    def _online_embed(self, count: int) -> dict:
        c = self.cfg
        fields = [
            {"name": "📡 IP", "value": f"`{c.get('server_ip')}`", "inline": True},
            {"name": "🔌 Port", "value": f"`{c.get('server_port')}`", "inline": True},
        ]
        if c.get("show_player_count", True):
            mx = int(c.get("max_players", 0) or 0)
            val = f"🟢 **{count}**" + (f" / {mx}" if mx > 0 else "") + " online"
            fields.append({"name": "👥 Players", "value": val, "inline": False})
        embed = {
            "title": c.get("online_title"),
            "description": c.get("online_desc"),
            "color": int(c.get("online_color", 3066993)),
            "fields": fields,
            "footer": {"text": f"{c.get('footer_text')} • last updated"},
            "timestamp": self._now_ts(),
        }
        if c.get("thumbnail_url"):
            embed["thumbnail"] = {"url": c["thumbnail_url"]}
        return embed

    def _restart_embed(self) -> dict:
        c = self.cfg
        embed = {
            "title": c.get("restart_title"),
            "description": c.get("restart_desc"),
            "color": int(c.get("restart_color", 15158332)),
            "footer": {"text": c.get("footer_text")},
            "timestamp": self._now_ts(),
        }
        if c.get("thumbnail_url"):
            embed["thumbnail"] = {"url": c["thumbnail_url"]}
        return embed

    # ================= send / edit message =================
    def _webhook_msg_url(self, message_id: str) -> str:
        base = self.cfg.get("webhook_url", "").split("?")[0].rstrip("/")
        return f"{base}/messages/{message_id}"

    def _send_online(self, count: int = 0):
        """Create a fresh announcement (pings @everyone) and remember its message id to update later."""
        try:
            url = self.cfg["webhook_url"].split("?")[0].rstrip("/") + "?wait=true"
            content = ""
            allowed = {"parse": []}
            if self.cfg.get("mention_everyone", True):
                content = self.cfg.get("mention_text", "@everyone")
                allowed = {"parse": ["everyone", "roles"]}
            payload = {
                "content": content,
                "embeds": [self._online_embed(count)],
                "allowed_mentions": allowed,
            }
            res = self._post_json(url, payload, "POST")
            if res and res.get("id"):
                self._state["message_id"] = str(res["id"])
                self._save_state()
            self.logger.info(f"{G}Posted the online announcement to Discord{RS}")
        except urllib.error.HTTPError as e:
            self.logger.warning(f"discord online HTTP {e.code}: {e.read().decode('utf-8','replace')[:200]}")
        except Exception as e:
            self.logger.warning(f"discord online fail: {e}")

    def _update_count(self, count: int):
        """Edit the existing message to show the latest player count (no re-ping)."""
        mid = self._state.get("message_id")
        if not mid:
            return
        try:
            payload = {"embeds": [self._online_embed(count)]}
            self._post_json(self._webhook_msg_url(mid), payload, "PATCH")
        except urllib.error.HTTPError as e:
            if e.code == 404:  # message deleted → recreate
                self._state.pop("message_id", None)
                self._save_state()
                self._send_online(count)
            else:
                self.logger.warning(f"discord update HTTP {e.code}")
        except Exception as e:
            self.logger.warning(f"discord update fail: {e}")

    def _send_restart_blocking(self):
        """Called from on_disable — must be synchronous because the process is about to exit."""
        mid = self._state.get("message_id")
        try:
            if mid:
                # edit the existing message to red + clear the mention
                self._post_json(self._webhook_msg_url(mid),
                                {"content": "", "embeds": [self._restart_embed()],
                                 "allowed_mentions": {"parse": []}},
                                "PATCH", timeout=5.0)
            else:
                url = self.cfg["webhook_url"].split("?")[0].rstrip("/")
                self._post_json(url, {"embeds": [self._restart_embed()],
                                      "allowed_mentions": {"parse": []}}, "POST", timeout=5.0)
        except Exception as e:
            self.logger.warning(f"discord restart fail: {e}")

    # ================= player-count updater (scheduler) =================
    def _start_updater(self):
        if not self.cfg.get("show_player_count", True):
            return
        interval = max(10, int(self.cfg.get("update_interval_sec", 60)))
        try:
            self._task = self.server.scheduler.run_task(
                self, self._tick, delay=interval * 20, period=interval * 20)
        except Exception as e:
            self.logger.warning(f"scheduler fail: {e}")

    def _tick(self):
        # read the count on the main thread, then send HTTP off-thread
        try:
            count = len(self.server.online_players)
        except Exception:
            count = 0
        threading.Thread(target=self._update_count, args=(count,), daemon=True).start()

    def _online_count(self) -> int:
        try:
            return len(self.server.online_players)
        except Exception:
            return 0

    # ================= commands =================
    def _is_admin(self, sender) -> bool:
        # is_op in EndStone is a property (bool), not a method
        val = getattr(sender, "is_op", None)
        if val is None:
            return True  # console / Server = allowed
        if callable(val):
            try:
                return bool(val())
            except Exception:
                return False
        return bool(val)

    def on_command(self, sender: CommandSender, command: Command, args: list) -> bool:
        if command.name != "discord":
            return False
        if not self._is_admin(sender):
            sender.send_message(f"{PREFIX}{R}Admins only{RS}")
            return True

        # command is a 'message' type → EndStone passes everything as one string; split it ourselves
        raw = " ".join(str(a) for a in args).strip() if args else ""
        tokens = raw.split()
        sub = tokens[0].lower() if tokens else "help"

        if sub == "help" or not tokens:
            sender.send_message(
                f"{PREFIX}{AQ}LGX Discord commands{RS}\n"
                f"{W}/discord test {GR}— send a test ONLINE message\n"
                f"{W}/discord now {GR}— re-post the online announcement (pings @everyone)\n"
                f"{W}/discord restart {GR}— send the restarting message\n"
                f"{W}/discord setwebhook <url> {GR}— set the webhook URL\n"
                f"{W}/discord status {GR}— show settings\n"
                f"{W}/discord reload {GR}— reload config{RS}")
            return True

        if sub == "setwebhook":
            if len(tokens) < 2:
                sender.send_message(f"{PREFIX}{R}Usage: /discord setwebhook <url>{RS}")
                return True
            url = tokens[1].strip()  # do NOT lowercase — webhook tokens are case-sensitive
            if "discord.com/api/webhooks/" not in url and "discordapp.com/api/webhooks/" not in url:
                sender.send_message(f"{PREFIX}{R}Invalid URL — must be a Discord webhook link{RS}")
                return True
            self.cfg["webhook_url"] = url
            self._save_config()
            self._state.pop("message_id", None)
            self._save_state()
            sender.send_message(f"{PREFIX}{G}Webhook set! Try /discord test{RS}")
            return True

        if not self.cfg.get("webhook_url"):
            sender.send_message(f"{PREFIX}{R}No webhook set — use /discord setwebhook <url> first{RS}")
            return True

        if sub == "test":
            sender.send_message(f"{PREFIX}{Y}Sending a test message...{RS}")
            cnt = self._online_count()
            threading.Thread(target=self._test_send, args=(sender.name, cnt), daemon=True).start()
            return True

        if sub == "now":
            sender.send_message(f"{PREFIX}{Y}Re-posting the online announcement...{RS}")
            self._state.pop("message_id", None)  # force a new message = new ping
            self._save_state()
            cnt = self._online_count()
            threading.Thread(target=self._send_online, args=(cnt,), daemon=True).start()
            self._start_updater()
            return True

        if sub == "restart":
            sender.send_message(f"{PREFIX}{Y}Sending the restarting message...{RS}")
            threading.Thread(target=self._send_restart_blocking, daemon=True).start()
            return True

        if sub == "status":
            wh = self.cfg.get("webhook_url", "")
            wh_show = (wh[:45] + "...") if len(wh) > 48 else wh
            mid = self._state.get("message_id", "—")
            sender.send_message(
                f"{PREFIX}{AQ}LGX Discord status{RS}\n"
                f"{GR}Webhook: {W}{wh_show or '(not set)'}\n"
                f"{GR}Server: {W}{self.cfg.get('server_ip')}:{self.cfg.get('server_port')}\n"
                f"{GR}Ping @everyone: {W}{'on' if self.cfg.get('mention_everyone') else 'off'}\n"
                f"{GR}Show players: {W}{'on' if self.cfg.get('show_player_count') else 'off'} "
                f"(every {self.cfg.get('update_interval_sec')}s)\n"
                f"{GR}Players now: {W}{self._online_count()}\n"
                f"{GR}Message id: {W}{mid}{RS}")
            return True

        if sub == "reload":
            self._load_config()
            sender.send_message(f"{PREFIX}{G}Config reloaded{RS}")
            return True

        sender.send_message(f"{PREFIX}{R}Unknown command — type /discord{RS}")
        return True

    def _test_send(self, who: str, count: int):
        try:
            url = self.cfg["webhook_url"].split("?")[0].rstrip("/")
            embed = self._online_embed(count)
            embed["title"] = "🧪 LGX Discord test message"
            embed["footer"] = {"text": f"tested by {who}"}
            self._post_json(url, {"embeds": [embed], "allowed_mentions": {"parse": []}}, "POST")
            self.logger.info(f"{G}Test message sent{RS}")
        except urllib.error.HTTPError as e:
            self.logger.warning(f"discord test HTTP {e.code}: {e.read().decode('utf-8','replace')[:200]}")
        except Exception as e:
            self.logger.warning(f"discord test fail: {e}")
