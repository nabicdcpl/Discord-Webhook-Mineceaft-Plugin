from endstone_lgx_discord.plugin import LGXDiscord
__all__ = ["LGXDiscord"]
