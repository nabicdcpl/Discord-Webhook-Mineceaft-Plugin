# LGX Discord

**Post your server's status to Discord automatically — no bot required.**

Uses a plain **Discord Webhook**. When the server starts it posts an "ONLINE" announcement (with IP/Port and an optional `@everyone` ping); while online it keeps the live player count updated on that same message; and when the server stops/restarts it edits the message to "Restarting...".

## Features

- 🟢 **Online announcement** on server start, with IP/Port and optional `@everyone` (or role) ping
- 👥 **Live player count** refreshed on the same message (no channel spam, no re-pinging)
- 🔄 **Restart notice** — the message turns red automatically when the server goes down
- 🪶 **Webhook only** — no bot token, no separate process to host
- 🎨 Fully customizable text, colors, and thumbnail via config

## Requirements

- EndStone `0.11+` (Bedrock Dedicated Server)

## Install

1. Download the `.whl` from [Releases](../../releases) and drop it in `plugins/`.
2. Restart the server.
3. Get a webhook URL: **Discord channel → Edit Channel → Integrations → Webhooks → New Webhook → Copy Webhook URL**
4. In-game or console:
   ```
   /discord setwebhook <your webhook url>
   /discord test
   ```
   If the test message appears in your channel, you're done — every server start now announces automatically.

## Commands

All commands require OP. Alias: `/dc`

| Command | Description |
| --- | --- |
| `/discord setwebhook <url>` | Set the webhook URL |
| `/discord test` | Send a test message (no ping) |
| `/discord now` | Re-post the online announcement (pings `@everyone` again) |
| `/discord restart` | Send the "restarting" message |
| `/discord status` | Show current settings |
| `/discord reload` | Reload config |

## Configuration (`config.json`)

```json
{
  "webhook_url": "",
  "server_name": "My Server",
  "server_ip": "play.example.net",
  "server_port": "19132",
  "max_players": 100,
  "mention_everyone": true,
  "mention_text": "@everyone",
  "show_player_count": true,
  "update_interval_sec": 60,
  "online_title": "🎉 THE SERVER IS NOW ONLINE! 🎉",
  "online_desc": "...",
  "online_color": 3066993,
  "restart_title": "🔄 Server is restarting...",
  "restart_desc": "...",
  "restart_color": 15158332,
  "thumbnail_url": "",
  "footer_text": "My Server"
}
```

- **mention_text** — set to `<@&ROLE_ID>` to ping a specific role instead of `@everyone`.
- **max_players** — shows `X / Y`. Set `0` to hide the cap.
- **online_color / restart_color** — decimal color values (green / red by default).

> The webhook URL contains a secret token. Keep it private, and reset it in Discord if it ever leaks.

## License

MIT — see [LICENSE](LICENSE).
